/* $Id: blossom_engine_math.h 126 2009-08-22 17:08:39Z maxest $ */

#ifndef _BLOSSOM_MATH_
#define _BLOSSOM_MATH_

#include "vector.h"
#include "matrix.h"
#include "plane.h"
#include "math_common.h"

#endif
