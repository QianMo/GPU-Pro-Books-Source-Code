/* $Id: blossom_engine_video_manager.h 126 2009-08-22 17:08:39Z maxest $ */

#ifndef _BLOSSOM_VIDEO_MANAGER_
#define _BLOSSOM_VIDEO_MANAGER_

//#include "material.h"
//#include "light.h"
#include "mesh.h"
//#include "sprites_manager.h"
//#include "gui_manager.h"
//#include "video_manager.h"

#endif
