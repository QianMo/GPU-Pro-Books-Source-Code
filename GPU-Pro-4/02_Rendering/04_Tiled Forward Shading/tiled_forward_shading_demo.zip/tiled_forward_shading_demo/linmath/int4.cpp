#include "int4.h"

template class chag::SmallVector4<int>;