/* $Id: blossom_engine.h 126 2009-08-22 17:08:39Z maxest $ */

#ifndef _BLOSSOM_
#define _BLOSSOM_

#include "common/blossom_engine_common.h"
#include "math/blossom_engine_math.h"
#include "renderer/blossom_engine_renderer.h"
#include "video_manager/blossom_engine_video_manager.h"
//#include "audio_manager/blossom_engine_audio_manager.h"

#endif
