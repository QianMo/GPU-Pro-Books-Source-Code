#include "HashFunction.h"
#include "HashVector.h"
#include <string.h>
#include <stdlib.h>

