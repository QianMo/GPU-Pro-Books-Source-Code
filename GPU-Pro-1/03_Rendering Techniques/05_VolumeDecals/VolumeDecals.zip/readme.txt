Author
======

This demo was made by Emil Persson, AKA Humus.
http://www.humus.name



Controls
========

F1 opens the settings dialog. In addition to general settings
decal color selection is available on the F1 dialog.

Left mouse button places a decal at the center of the screen.



Troubleshooting
===============

Is there a problem running the demo?
Refer to my site for information and ways to contact me if there is a problem.
I appreciate bug-reports and feedback.

If you're experiencing a "side-by-side configuration" problem, installing the MSVC++
runtime redist should fix it:
http://www.microsoft.com/downloads/details.aspx?familyid=200B2FD9-AE1A-4A14-984D-389C36F85647

If you're getting an error about a missing d3dx dll file, try installing the latest runtime components:
http://www.microsoft.com/downloads/details.aspx?FamilyId=2DA43D38-DB71-4C1B-BC6A-9B6652CD92A3
