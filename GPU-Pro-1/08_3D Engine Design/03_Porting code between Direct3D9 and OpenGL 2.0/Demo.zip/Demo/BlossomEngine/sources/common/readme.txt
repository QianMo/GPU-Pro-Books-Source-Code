$Id: readme.txt 281 2009-09-11 01:56:17Z maxest $

- CCamera is fully valid only for right-handed coordinate system with Y axis pointing up
